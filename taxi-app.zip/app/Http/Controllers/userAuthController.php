<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class userAuthController extends Controller
{
    //
    function login(Request $request){
        $user = User::where('email',$request->email)->first();
        if(!$user || !Hash::check($request->password,$user->password)){
            return ['response'=>false, 'msg'=>'The combination of username and password is not found!'];
        }else{
            $token = $user->createToken("taxiApp")->plainTextToken;

        }
        return ['response'=>true, 'user'=>$user,'token'=>$token];
    }

    function signup(Request $request){
        $input = $request->all();
        $input["password"] = \bcrypt($input["password"]); 
        $input["status"] = 1; 
        $user = User::create($input);
        $token = $user->createToken("taxiApp")->plainTextToken;
        $user["name"] = $user->name;
        $user["email"] = $user->email;
        $user["status"] = $user->status;
        return ['response'=>true,'token'=>$token,'data'=>$user];
    }
}
