<?php

use App\Http\Controllers\userAuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::post('signup', [userAuthController::class,'signup']);
Route::post('login', [userAuthController::class,'login']);
